'use strict';

const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {protos, QuestionServiceClient} = require('@google-cloud/data-qna');
const {Question, CreateQuestionRequest} = protos.google.cloud.dataqna.v1alpha;
const {BigQuery} = require('@google-cloud/bigquery');
const Table = require('cli-table');

process.env.DEBUG = 'dialogflow:debug';

// Credentials and info

const project = ""; // Name of the project containing BigQuery data
const location = ""; // Location in which data is stored - "us" or "eu"
const dataset = ""; // Name of BigQuery dataset
const table = ""; // Name of table in dataset. Table must have Data QnA enabled


const apiEndpoint= `${location}-dataqna.googleapis.com`;
const settings = {
	apiEndpoint
};
const qs = new QuestionServiceClient(settings);
const parent = qs.locationPath(project, location);
const scope = `//bigquery.googleapis.com/projects/${project}/datasets/${dataset}/tables/${table}`;

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
	const agent = new WebhookClient({ request, response });
	console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
	console.log('Dialogflow Request body: ' + JSON.stringify(request.body));

	function welcome(agent) {
		agent.add(`Welcome to Data Assistant! Ask anything about your bigquery table`);
	}

	function fallback(agent) {
		return queryHandler(agent);
	}

	let intentMap = new Map();
	intentMap.set('Default Welcome Intent', welcome);
	intentMap.set('Default fallback intent', fallback);
	agent.handleRequest(intentMap);
});

function queryHandler(agent) {
	const question = new Question({
		scopes: [scope],
		query: agent.query
	});

	const request = new CreateQuestionRequest({
		parent,
		question
	});

	return new Promise((resolve, reject) => {
		qs.createQuestion(request)
			.then(([created_question]) => {
				if (created_question.interpretations.length > 0) {
					qs.executeQuestion({
						name: created_question.name,
						interpretationIndex: 0
					}).then(([response]) => {
						const created_job = response.interpretations[0].executionInfo.bigqueryJob;

						const bq = new BigQuery();
						const run_job = bq.job(created_job.jobId);

						run_job.getQueryResults()
							.then(([results]) => {
								agent.add(tabularize(results));
								resolve();
							});
					});         
				} else {
					agent.add("No valid interpretations found. Please try a different query");
					resolve();
				}
			});
	});
}

function tabularize(res) {
	const header = Object.keys(res[0]);
	const maxWidth = 80;
	const colWidths = Array(header.length).fill(maxWidth/header.length);
	console.log(colWidths);
	let table = new Table({
		head: header,
		colWidths
	});

	for (let item of res) {
		let row = [];
		for (let key of header) {
			row.push(item[key]);
		}
		table.push(row);
	}
	return table.toString();
}
